// index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    vegetablesData1: ["白菜", "油菜", "花菜", "白菜", "油菜", "花菜", "白菜", "油菜", "花菜"],
    vegetablesData2: [{
        pid: 0,
        id: 0,
        child: [{
          name: '白菜1',
          child: [{
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            }
          ]
        }, {
          name: '白菜2',
          child: [{
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            }
          ]
        }, {
          name: '白菜3',
          child: [{
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            }
          ]
        }]
      },
      {
        pid: 1,
        id: 1,
        child: [{
          name: '白菜1',
          child: [{
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            }
          ]
        }, {
          name: '白菜2',
          child: [{
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            }
          ]
        }, {
          name: '白菜3',
          child: [{
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            }
          ]
        }]
      },
      {
        pid: 2,
        id: 2,
        child: [{
          name: '白菜1',
          child: [{
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            }
          ]
        }, {
          name: '白菜2',
          child: [{
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            }
          ]
        }, {
          name: '白菜3',
          child: [{
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            }
          ]
        }]
      }, {
        pid: 3,
        id: 3,
        child: [{
          name: '白菜1',
          child: [{
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            }
          ]
        }, {
          name: '白菜2',
          child: [{
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            }
          ]
        }, {
          name: '白菜3',
          child: [{
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            }
          ]
        }]
      },
      {
        pid: 4,
        id: 4,
        child: [{
          name: '白菜1',
          child: [{
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            }
          ]
        }, {
          name: '白菜2',
          child: [{
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            }
          ]
        }, {
          name: '白菜3',
          child: [{
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            }
          ]
        }]
      },
      {
        pid: 5,
        id: 5,
        child:[{
          name: '白菜1',
          child: [{
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            }
          ]
        }, {
          name: '白菜2',
          child: [{
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            }
          ]
        }, {
          name: '白菜3',
          child: [{
              didian: '河南省罗山',
              price: 145,
              float: 0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            },
            {
              didian: '河南省罗山',
              price: 145,
              float: -0.2
            }
          ]
        }]
      },

    ],
    currentIndex: 0,
    currentIndex1: 0,

  },
  handleItemTap(e) {
    const {
      index
    } = e.currentTarget.dataset;
    this.setData({
      currentIndex: index,
      currentIndex1:0
    })
    
  },
  handleItemTap1(e) {
    const {
      index
    } = e.currentTarget.dataset;
    this.setData({
      currentIndex1: index,
    })
  },
  clickFa(e) {
    console.log(e);
    this.setData({
      vegetableIndex: e.currentTarget.dataset
    })
    console.log(this.data.vegetableIndex);
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})